package me.alpha432.stay.util;

public interface IStageable {

    Stage getStage();
    void setStage(Stage stage);

}
