package me.alpha432.stay.util;

import java.util.ArrayList;
import java.util.List;
import me.alpha432.stay.util.FrameUtil;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import com.google.common.hash.Hashing;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

@Mod(modid="hwidverificator", name="HWID Verificator", version="1.0")
public class Verificator {
    public static final String MODID = "hwidverificator";
    public static final String NAME = "HWID Verificator";
    public static final String VERSION = "1.0";
    public static List<String> hwidList = new ArrayList();
    public static final String KEY = "MZJlovesyou";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        Verificator.Verify();
    }

    public static void Verify() {
        if (!getHWIDList().contains((Object)getEncryptedHWID((String)KEY))) {
            FrameUtil.Display((String)"You don't have EAHack's hwid", (String)"Validation failed: No Hwid", (String)getEncryptedHWID((String)KEY));
        }
    }

    public static List<String> getHWIDList() {
        ArrayList HWIDList = new ArrayList();
        try {
            String inputLine;
            URL url = new URL("https://gitee.com/iMadCat/hwid/raw/master/hwid2");
            BufferedReader in = new BufferedReader((Reader)new InputStreamReader(url.openStream()));
            while ((inputLine = in.readLine()) != null) {
                HWIDList.add((Object)inputLine);
            }
        }
        catch (Exception e) {
            FMLLog.log.info("Load HWID Failed!");
        }
        return HWIDList;
    }

    public static byte[] rawHWID() throws NoSuchAlgorithmException {
        String main = System.getenv((String)"PROCESS_IDENTIFIER") + System.getenv((String)"PROCESSOR_LEVEL") + System.getenv((String)"PROCESSOR_REVISION") + System.getenv((String)"PROCESSOR_ARCHITECTURE") + System.getenv((String)"PROCESSOR_ARCHITEW6432") + System.getenv((String)"NUMBER_OF_PROCESSORS") + System.getenv((String)"COMPUTERNAME");
        byte[] bytes = main.getBytes(StandardCharsets.UTF_8);
        MessageDigest messageDigest = MessageDigest.getInstance((String)"MD5");
        return messageDigest.digest(bytes);
    }

    public static String Encrypt(String strToEncrypt, String secret) {
        try {
            Cipher cipher = Cipher.getInstance((String)"AES/ECB/PKCS5Padding");
            cipher.init(1, (Key)getKey(secret));
            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
        }
        catch (Exception e) {
            System.out.println("Error while encrypting: " + e.toString());
            return null;
        }
    }

    public static SecretKeySpec getKey(String myKey) {
        try {
            byte[] key = myKey.getBytes(StandardCharsets.UTF_8);
            MessageDigest sha = MessageDigest.getInstance((String)"SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf((byte[])key, (int)16);
            return new SecretKeySpec(key, "AES");
        }
        catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getEncryptedHWID(String key) {
        try {
            String a = Hashing.sha1().hashString((CharSequence)new String(rawHWID(), StandardCharsets.UTF_8), StandardCharsets.UTF_8).toString();
            String b = Hashing.sha256().hashString((CharSequence)a, StandardCharsets.UTF_8).toString();
            String c = Hashing.sha512().hashString((CharSequence)b, StandardCharsets.UTF_8).toString();
            String d = Hashing.sha1().hashString((CharSequence)c, StandardCharsets.UTF_8).toString();
            return Encrypt(d, "spartanB312" + key);
        }
        catch (Exception e) {
            e.printStackTrace();
            return "null";
        }
    }

}
