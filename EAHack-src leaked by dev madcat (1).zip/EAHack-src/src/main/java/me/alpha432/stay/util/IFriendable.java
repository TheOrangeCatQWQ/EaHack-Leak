package me.alpha432.stay.util;

public interface IFriendable {
    String getAlias();
    void setAlias(String alias);
}
