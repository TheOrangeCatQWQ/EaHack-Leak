/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 */
package me.alpha432.stay.features.modules.player;

import me.alpha432.stay.features.modules.Module;
import me.alpha432.stay.features.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;

public class Reach
        extends Module {
    private final Setting<Integer> Reach = this.register(new Setting<Integer>("Reach", 6, 5, 10));

    public Reach() {
        super("Reach", "reach", Module.Category.PLAYER, true, false, false);
    }

    @Override
    public void onUpdate() {
        me.alpha432.stay.features.modules.player.Reach.mc.player.getEntityAttribute(EntityPlayer.REACH_DISTANCE).setBaseValue((double)this.Reach.getValue().intValue());
    }

    @Override
    public void onDisable() {
        me.alpha432.stay.features.modules.player.Reach.mc.player.getEntityAttribute(EntityPlayer.REACH_DISTANCE).setBaseValue(5.0);
    }
}

