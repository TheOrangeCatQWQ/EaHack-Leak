package me.alpha432.stay.util;

public enum Stage {
    PRE,
    POST
}
