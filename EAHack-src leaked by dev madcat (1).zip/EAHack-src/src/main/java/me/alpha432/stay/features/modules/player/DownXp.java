/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItem
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.NonNullList
 */
package me.alpha432.stay.features.modules.player;

import me.alpha432.stay.features.modules.Module;
import me.alpha432.stay.features.setting.Bind;
import me.alpha432.stay.features.setting.Setting;
import me.alpha432.stay.util.InventoryUtil;
import me.alpha432.stay.util.Timer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;

public class DownXp
        extends Module {
    public static DownXp INSTANCE;
    private final Timer timer = new Timer();
    private final Setting<Bind> bind = this.register(new Setting<Bind>("PacketBind", new Bind(-1)));
    char toMend = '\u0000';


    public DownXp() {
        super("DownXp", "DownXp", Module.Category.PLAYER, true, false, false);
        INSTANCE = this;
    }

    @Override
    public void onUpdate() {
        if (DownXp.fullNullCheck()) {
            return;
        }
        if (this.bind.getValue().isDown() && mc.currentScreen == null) {
            this.mendArmor();
        }
    }

    private void mendArmor() {
        int a = InventoryUtil.getItemHotbar(Items.EXPERIENCE_BOTTLE);
        int b = DownXp.mc.player.inventory.currentItem;
        if (a == -1) {
            return;
        }
        DownXp.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(DownXp.mc.player.rotationYaw, 90.0f, true));
        DownXp.mc.player.inventory.currentItem = a;
        DownXp.mc.playerController.updateController();
        DownXp.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
        DownXp.mc.player.inventory.currentItem = b;
        DownXp.mc.playerController.updateController();
    }
}

